import os

# def check_cpu(command):
#     print(os.system(command))

# def check_date(command):
#     print(os.system(command))

def run_command(command):
    return os.system(command)

run_command("date")




