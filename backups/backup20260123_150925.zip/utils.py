import os 

print(os.system('df -h'))



