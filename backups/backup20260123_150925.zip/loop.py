list_of_name = ["Meet","Raj","Tirth"]

print(list_of_name)


list_of_name.append("Bhargav")
print(list_of_name)



list_of_name.insert(2,"Axay")
print(list_of_name)



for name in list_of_name:
    print(name)



for i in range(0,20):
    print(i)



for i in range(1,11):
    print("hello Meet")



