num1 = int(input("Enter First Number : "))
num2 = int(input("Enter second Number : "))

sum = num1+num2

print(sum)

diff = num1 - num2

print(diff)

