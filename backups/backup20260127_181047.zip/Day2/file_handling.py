#Write File
# file = open("data.txt", "w")   
# file.write("Hello Python\n")
# file.write("File Handling")
# file.close()


#Read File
# file = open("data.txt", "r")   
# content = file.read()         
# print(content)
# file.close()    

#Append Mode
file = open("data.txt", "a")
file.write("\nNew Line Added")
file.close()






