import sys
import os 

# a = sys.argv[1]
# b = sys.argv[2]

# print(a+b)


# a = int(sys.argv[1])
# b = int(sys.argv[2])

# print(a+b)

path = sys.argv[1]
files = os.listdir(path)

# print(len(files))
print(files)








