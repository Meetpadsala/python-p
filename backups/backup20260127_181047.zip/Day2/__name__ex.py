def main():
    print("hiii")

if __name__ == "__main__":
    main()