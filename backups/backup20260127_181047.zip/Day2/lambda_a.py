# add = lambda a, b: a + b
# print(add(3, 7))  



# multiply = lambda a, b, c: a * b * c
# print(multiply(2, 3, 4))  

# print((lambda x: x + 5)(10))  


numbers = [1, 2, 3, 4, 5]
# num = list(map(lambda x: x**2 , numbers))
# print(num)


even = list(filter(lambda x: x%2 == 0 ,numbers))
print(even)



